export type state = {
    state_id?: number;
    state: string;
    created_by?: Date;
    updated_by?: Date;
    created_on?: Date;
    updated_on?: Date;
};
