export type categoryMaster = {
    category_id?: number;
    category_master: string;
    status: boolean;
    created_by?: string;
    updated_by?: string;
    created_on?: Date;
    updated_on?: Date;
};
