import "reflect-metadata";
import { DataSource } from "typeorm";
import {
  CATEGORY_MASTER,
  PRIVACY,
  SUBCATEGORY,
  CONDITION,
  STATE,
} from "./entity";

export const AppDataSource = new DataSource({
  type: "mysql",
  host: "localhost",
  port: 3306,
  username: "root",
  // password: 'Addy@789**$',
  password: "root",
  database: "cryztal_dev",
  synchronize: true,
  logging: false,
  entities: [
    CATEGORY_MASTER.CategoryMaster,
    PRIVACY.PrivacyPolicy,
    SUBCATEGORY.SubCategoryMater,
    CONDITION.TermsAndCondition,
    STATE.State,
  ],
  migrations: [],
  subscribers: [],
});
