/* eslint-disable jsdoc/check-param-names */
import { AppDataSource } from "../../data-source";
import { PRIMARY, CATEGORY_MASTER, SUBCATEGORY } from "../../entity";
import log from "../../logger/logger";
import * as moment from "moment";
import { FindOperator, Like } from "typeorm";
//import { string } from 'yup';
const CurrentDate = moment().format("DD/MM/YYYY");
import * as nodemailer from "nodemailer";
/**
 *
 */
export class PRODUCTSService {
  private dealRepository = AppDataSource.getRepository(
    PRIMARY.PRODUCTS.PRODUCTS
  );
  private categoryDealRepository = AppDataSource.getRepository(
    CATEGORY_MASTER.CategoryMaster
  );
  private subCategoryDealRepository = AppDataSource.getRepository(
    SUBCATEGORY.SubCategoryMater
  );

  /**
   *
   * @param {TYPES.PRODUCTS} req -- From Request body object
   * @returns {any} -- DB response SQL Response
   */
  async register(req: TYPES.PRODUCTS): Promise<any> {
    let PRODUCTS = new PRIMARY.PRODUCTS.PRODUCTS();
    req.qr_id = `${req.partner_id},${req.category}, ${req.deal_name},${req.from_date},${req.to_date}`;
    PRODUCTS = req;
    try {
      return this.dealRepository.save(PRODUCTS);
    } catch (error) {
      log.error(error);
      return error;
    }
  }

  /**
   * @param {TYPES.PRODUCTS} req -- From Request body object
   * @returns {any} -- DB response SQL Response
   * @param {boolean} isSearch -- based on boolean search query enabled
   * @param {string} keyword -- Keyword for search
   */
  async getAll(req: number, isSearch: boolean, keyword: string): Promise<any> {
    let whereObj: {
      partner_id: { id: number } | { id: number };
      deal_name?: FindOperator<string>;
    };
    if (isSearch) {
      whereObj = {
        partner_id: { id: req },
        deal_name: Like(`%${keyword}%`),
      };
    } else {
      whereObj = {
        partner_id: { id: req },
      };
    }
    try {
      return this.dealRepository.find({
        relations: {
          partner_id: true,
        },
        where: whereObj,
      });
    } catch (error) {
      log.error(error);
      return error;
    }
  }

  /**
   *
   * @param {TYPES.PRODUCTS} req -- From Request body object
   * @returns {any} -- DB response SQL Response
   */
  async get(req: number): Promise<any> {
    try {
      return this.dealRepository.findOne({
        relations: {
          partner_id: true,
        },
        where: {
          id: req,
        },
      });
    } catch (error) {
      log.error(error);
      return error;
    }
  }
  /**
   *
   * @param {TYPES.PRODUCTS} req -- From Request body object
   * @param {number} id -- Unique id for th table PRODUCTS
   * @returns {any} -- DB response SQL Response
   */
  async update(req: TYPES.PRODUCTS, id: number): Promise<any> {
    try {
      return this.dealRepository.update(
        { id: id },
        {
          category: req.category,
          sub_category: req.sub_category,
          deal_name: req.deal_name,
          discount_description: req.discount_description,
          offer: req.offer,
          from_date: req.from_date,
          to_date: req.to_date,
          image: req.image,
          reference_code: req.reference_code,
          updated_by: req.id,
          updated_on: CurrentDate,
        }
      );
    } catch (error) {
      log.error(error);
      return error;
    }
  }
  /**
   * @returns {any} -- DB response SQL Response
   * @param {boolean} isSearch -- based on boolean search query enabled
   * @param {string} keyword -- Keyword for search
   * @param {boolean} isFilter --status isFilter
   * @param {number} filter --status filter
   */
  async getAdminDealAll(
    isSearch: boolean,
    keyword: string,
    filter: number,
    isFilter: boolean
  ): Promise<any> {
    let whereObj: { deal_name?: FindOperator<string>; status?: number };
    if (isSearch && isFilter) {
      whereObj = {
        deal_name: Like(`%${keyword}%`),
        status: filter,
      };
    } else if (isSearch) {
      whereObj = {
        deal_name: Like(`%${keyword}%`),
      };
    } else if (isFilter) {
      whereObj = {
        status: filter,
      };
    }
    try {
      return this.dealRepository.find({
        relations: {
          partner_id: true,
        },
        where: whereObj,
      });
    } catch (error) {
      log.error(error);
      return error;
    }
  }
  /**
   *
   * @param {TYPES.PRODUCTS} req -- From Request body object
   * @param {number} id  -- Unique id for th table PRODUCTS
   * @returns {any} -- DB response SQL Response
   */
  async updateAdminDeal(req: TYPES.PRODUCTS, id: number): Promise<any> {
    const status_code = req.status;

    try {
      return this.dealRepository.update(
        { id: id },
        {
          status: status_code,
          updated_by: req.id,
          updated_on: CurrentDate,
        }
      );
    } catch (error) {
      log.error(error);
      return error;
    }
  }
  /**
   *
   * @param {TYPES.PRODUCTS} req -- From Request body object
   * @returns {any} -- DB response SQL Response
   */
  async getAdminPartnerId(req: number) {
    try {
      return this.dealRepository.findOneBy({
        id: req,
      });
    } catch (error) {
      log.error(error);
      return error;
    }
  }
  /**
   * @param {TYPES.PRODUCTS} req -- From Request body object
   * @returns {any} -- DB response SQL Response
   * @param {boolean} isSearch -- based on boolean search query enabled
   * @param {string} keyword -- Keyword for search
   */
  async getAllActiveDeal(
    req: number,
    isSearch: boolean,
    keyword: string
  ): Promise<any> {
    let whereObj: {
      partner_id: { id: number } | { id: number };
      deal_name?: FindOperator<string>;
    };
    if (isSearch) {
      whereObj = {
        partner_id: { id: req },
        deal_name: Like(`%${keyword}%`),
      };
    } else {
      whereObj = {
        partner_id: { id: req },
      };
    }
    try {
      return this.dealRepository.find({
        relations: {
          partner_id: true,
        },
        where: whereObj,
      });
    } catch (error) {
      log.error(error);
      return error;
    }
  }
  /**
   *
   * @param {TYPES.PRODUCTS} status -- From Request body object
   * @returns {any} -- DB response SQL Response
   */
  async getActivePRODUCTS(status: number): Promise<any> {
    try {
      return this.dealRepository.find({
        where: {
          status: status,
        },
      });
    } catch (error) {
      log.error(error);
      return error;
    }
  }
  /**
   *
   * @param {TYPES.PRODUCTS} req -- From Request body object
   * @returns {any} -- DB response SQL Response
   */
  async getActivePRODUCTSById(req: number): Promise<any> {
    try {
      return this.dealRepository.find({
        where: {
          id: req,
        },
      });
    } catch (error) {
      log.error(error);
      return error;
    }
  }
  /**
   *
   * @returns {any} -- DB response SQL Response
   */
  async getCategoryPRODUCTS(): Promise<any> {
    try {
      return this.categoryDealRepository.find({
        where: {
          status: true,
        },
      });
    } catch (error) {
      log.error(error);
      return error;
    }
  }
  /**
   *
   * @returns {any} -- DB response SQL Response
   */
  async getSubCategoryPRODUCTS(): Promise<any> {
    try {
      return this.subCategoryDealRepository.find({
        where: {
          status: true,
        },
      });
    } catch (error) {
      log.error(error);
      return error;
    }
  }
  /**
   * @param {string} id --
   * @returns {any} -- DB response SQL Response
   */
  async getPartnerDashboardCount(id: number): Promise<any> {
    try {
      const data: any = {
        PRODUCTSCount: 0,
        todayPRODUCTS: 0,
        totalViews: 1,
        todayViews: 1,
      };
      data.PRODUCTSCount = await this.dealRepository.count({
        relations: {
          partner_id: true,
        },
        where: {
          partner_id: {
            id: id,
          },
        },
      });
      data.todayPRODUCTS = await this.dealRepository.count({
        relations: {
          partner_id: true,
        },
        where: {
          partner_id: {
            id: id,
          },
          created_on: CurrentDate,
        },
      });

      return data;
    } catch (error) {
      log.error(error);
      return error;
    }
  }
  /**
   *@param {any} id --
   * @returns {any} -- DB response SQL Response
   */
  async geTodayPRODUCTSCount(id: any): Promise<any> {
    try {
      const data: any = {
        PRODUCTSCount: 0,
      };
      data.PRODUCTSCount = await this.dealRepository.count({
        relations: {
          partner_id: true,
        },
        where: {
          partner_id: {
            id: id,
          },
          created_on: CurrentDate,
        },
      });
      return data;
    } catch (error) {
      log.error(error);
      return error;
    }
  }

  /**
   *
   * @param {id}  -- From Request body object
   * @param id
   * @returns {any} -- DB response SQL Response
   */
  async getPRODUCTSData(id: number) {
    return this.dealRepository.findOne({
      relations: {
        partner_id: true,
      },
      where: {
        id: id,
      },
    });
  }
  /**
   *
   * @param {email,email_status}  -- From Request body object
   * @param email
   * @param email_status
   * @returns {any} -- DB response SQL Response
   */
  async PRODUCTSApprovalMailSend(email: string, email_status: number) {
    try {
      let email_data = "";

      switch (email_status) {
        case 0:
          email_data = "Rejected";
          break;
        case 1:
          email_data = "approval";
          break;
        case 2:
          email_data = "quarantine";
          break;
        default:
          email_data = "no status";
      }

      const transporter = nodemailer.createTransport({
        host: "paladinsoftwares.com",
        port: 465,
        // secureConnection:false,
        tls: {
          rejectUnauthorized: false,
        },
        auth: {
          user: "samuelraj@paladinsoftwares.com",
          pass: "sammas(2&",
        },
      });
      const mailOptions = {
        to: email,
        from: "samuelraj@paladinsoftwares.com",
        subject: "Cryztal",
        text: `${email_data}`,
      };

      transporter.sendMail(mailOptions, async function (error, info) {
        if (error) {
          console.log(error);
          return error;
        } else {
          console.log("Email sent: " + info.response);
          return info.response;
        }
      });
    } catch (error) {
      log.error(error);
      return error;
    }
  }
}
