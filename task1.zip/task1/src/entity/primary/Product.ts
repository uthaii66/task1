import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
} from "typeorm";
import * as moment from "moment";
const CurrentDate = moment().format("DD/MM/YYYY");

@Entity({ name: "c_tbl_pm_partner_PRODUCTS" })
/**
 * ! PRODUCTS Entity/Model
 *  ? To define the table structure with ORM Specifications
 */
export class PRODUCTS {
  // @PrimaryGeneratedColumn('uuid')
  @PrimaryGeneratedColumn()
  id?: number;

  @Column({ type: "varchar", nullable: false })
  qr_id: string;

  @Column({ type: "varchar", nullable: false })
  category: string;

  @Column({ type: "varchar", nullable: false })
  sub_category: string;

  @Column({ type: "varchar", nullable: false })
  deal_name: string;

  @Column({ type: "varchar", nullable: false })
  offer: string;

  @Column({ type: "varchar", nullable: false })
  discount_description: string;

  @Column({ type: "varchar", nullable: false })
  from_date: Date;

  @Column({ type: "varchar", nullable: false })
  to_date: Date;

  @Column("simple-array")
  image: string[];

  @Column({ type: "varchar", nullable: true })
  reference_code: string;

  @Column({ type: "int", nullable: false, default: 0 })
  status: number;

  @Column({ type: "varchar", nullable: true })
  created_by?: Date;

  @Column({ type: "varchar", nullable: true })
  updated_by?: Date;

  @Column({ type: "varchar", nullable: false, default: CurrentDate.toString() })
  created_on?: string;

  @Column({ type: "varchar", nullable: true })
  updated_on?: Date;
}
