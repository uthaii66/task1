import * as CATEGORY_MASTER from "./master/CategoryMaster";
import * as PRIVACY from "./master/PrivacyPolicy";
import * as SUBCATEGORY from "./master/SubCategoryMaster";
import * as CONDITION from "./master/TermsAndCondition";
import * as STATE from "./master/State";

export { CATEGORY_MASTER, PRIVACY, SUBCATEGORY, CONDITION, STATE };
