export const default_omit_arr = ['created_by', 'updated_by', 'created_on', 'updated_on', 'delete_status', 'password'];
