import * as CATEGORY_HANDLER from "./master/CategoryMasterController";
import * as CONDITION_HANDLER from "./master/TermsAndConditionMasterController";
import * as PRIVACY_HANDLER from "./master/PrivacyPolicyController";
import * as SUB_HANDLER from "./master/SubCategoryController";
import * as STATE_HANDLER from "./master/StateController";

export {
  CATEGORY_HANDLER,
  CONDITION_HANDLER,
  PRIVACY_HANDLER,
  SUB_HANDLER,
  STATE_HANDLER,
};
