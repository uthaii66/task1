import * as CATEGORY_SCHEMA from "./master/CategoryMasterSchema";
import * as CONDITION_SCHEMA from "./master/TermsAndConditionMasterSchema";
import * as PRIVACY_SCHEMA from "./master/PrivacyPolicy.Schema";
import * as SUB_SCHEMA from "./master/SubCategory.Schema";
import * as TERMS_AND_CONDITION_SCHEMA from "./master/TermsAndConditionMasterSchema";

export {
  CONDITION_SCHEMA,
  CATEGORY_SCHEMA,
  PRIVACY_SCHEMA,
  SUB_SCHEMA,
  TERMS_AND_CONDITION_SCHEMA,
};
