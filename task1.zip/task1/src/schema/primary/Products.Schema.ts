import { object, string, number, array, bool } from "yup";
const payload = {
  body: object({
    partner_id: number().required("partner_id is required"),
    category: string().required("category is required"),
    sub_category: string().required("sub_category  is required"),
    deal_name: string().required("deal_name is required"),
    discount_description: string().required("discount_description is required"),
    offer: string().required("offer is required"),
    from_date: string().required("from_date is required"),
    to_date: string().required("to_date is required"),
    image: array().of(string()).required("image is required"),
    reference_code: string().required("reference_code is required"),
  }),
};

const uploadPayload = {
  body: object({
    category: string().required("category is required"),
    sub_category: string().required("sub_category  is required"),
    deal_name: string().required("deal_name is required"),
    offer: string().required("offer is required"),
    discount_description: string().required("discount_description is required"),
    from_date: string().required("from_date is required"),
    to_date: string().required("to_date is required"),
    image: array().of(string()).required("image is required"),
    reference_code: string().required("reference_code is required"),
  }),
};

export const createPRODUCTSSchema = object({
  ...payload,
});

export const getAllPRODUCTSForAdminIDSchema = object({
  body: object({
    isSearch: bool().required("isSearch is required"),
    keyword: string().when("isSearch", {
      is: true,
      then: string().required("keyword is required"),
      otherwise: string(),
    }),
    isFilter: bool().required("isFilter is required"),
    status: number().when("isFilter", {
      is: true,
      then: number().required("status is required"),
      otherwise: number(),
    }),
  }),
});

const params = {
  params: object({
    id: string().required("Deal Id is required"),
  }),
};
export const updatePRODUCTSSchema = object({
  ...params,
  ...uploadPayload,
});

const updateDealApprovalIDSchema = {
  body: object({
    status: number().required("status is required"),
  }),
};
export const updateDealApprovalSchema = object({
  ...params,
  ...updateDealApprovalIDSchema,
});
